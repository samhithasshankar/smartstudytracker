package com.study;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SpringBootApplication
@Controller
public class SmartStudyApplication {

    static Map<String, String> users = new HashMap<>();
    static Map<String, String> names = new HashMap<>();
    static Map<String, List<StudyRecord>> userHistory = new HashMap<>();

    static final String DATA_FOLDER = "data";
    static final String USERS_FILE = DATA_FOLDER + "/users.txt";
    static final String HISTORY_FILE = DATA_FOLDER + "/history.txt";

    static class StudyRecord {
        String date;
        String subject;
        int goal;
        int study;
        int phone;
        int distractions;
        int goalCompletion;
        int productivity;

        StudyRecord(String date, String subject, int goal, int study, int phone, int distractions) {
            this.date = date;
            this.subject = subject;
            this.goal = goal;
            this.study = study;
            this.phone = phone;
            this.distractions = distractions;

            if (goal > 0) {
                this.goalCompletion = (study * 100) / goal;
                if (this.goalCompletion > 100) this.goalCompletion = 100;
            } else {
                this.goalCompletion = 0;
            }

            this.productivity = this.goalCompletion - phone - (distractions * 5);
            if (this.productivity < 0) this.productivity = 0;
            if (this.productivity > 100) this.productivity = 100;
        }

        String display() {
            return "Date: " + date +
                    " | Subject: " + subject +
                    " | Goal: " + goal + " min" +
                    " | Studied: " + study + " min" +
                    " | Phone Usage: " + phone + " min" +
                    " | Distractions: " + distractions +
                    " | Goal Completion: " + goalCompletion + "%" +
                    " | Productivity: " + productivity + "%";
        }
    }

    public static void main(String[] args) {
        loadData();
        SpringApplication.run(SmartStudyApplication.class, args);
    }

    static String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes());
    }

    static String decode(String value) {
        return new String(Base64.getDecoder().decode(value));
    }

    static void loadData() {
        try {
            Files.createDirectories(Paths.get(DATA_FOLDER));

            if (Files.exists(Paths.get(USERS_FILE))) {
                for (String line : Files.readAllLines(Paths.get(USERS_FILE))) {
                    String[] parts = line.split("\\|");
                    if (parts.length == 3) {
                        String email = decode(parts[0]);
                        users.put(email, decode(parts[2]));
                        names.put(email, decode(parts[1]));
                    }
                }
            }

            if (Files.exists(Paths.get(HISTORY_FILE))) {
                for (String line : Files.readAllLines(Paths.get(HISTORY_FILE))) {
                    String[] parts = line.split("\\|");
                    if (parts.length == 7) {
                        String email = decode(parts[0]);
                        StudyRecord record = new StudyRecord(
                                parts[1],
                                decode(parts[2]),
                                Integer.parseInt(parts[3]),
                                Integer.parseInt(parts[4]),
                                Integer.parseInt(parts[5]),
                                Integer.parseInt(parts[6])
                        );

                        userHistory.putIfAbsent(email, new ArrayList<>());
                        userHistory.get(email).add(record);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void saveUsers() {
        try {
            Files.createDirectories(Paths.get(DATA_FOLDER));
            List<String> lines = new ArrayList<>();

            for (String email : users.keySet()) {
                lines.add(encode(email) + "|" + encode(names.get(email)) + "|" + encode(users.get(email)));
            }

            Files.write(Paths.get(USERS_FILE), lines);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void saveHistory() {
        try {
            Files.createDirectories(Paths.get(DATA_FOLDER));
            List<String> lines = new ArrayList<>();

            for (String email : userHistory.keySet()) {
                for (StudyRecord r : userHistory.get(email)) {
                    lines.add(encode(email) + "|" +
                            r.date + "|" +
                            encode(r.subject) + "|" +
                            r.goal + "|" +
                            r.study + "|" +
                            r.phone + "|" +
                            r.distractions);
                }
            }

            Files.write(Paths.get(HISTORY_FILE), lines);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static int totalStudyForDate(List<StudyRecord> records, String date) {
        int total = 0;
        for (StudyRecord r : records) {
            if (r.date.equals(date)) total += r.study;
        }
        return total;
    }

    static int sessionsForDate(List<StudyRecord> records, String date) {
        int count = 0;
        for (StudyRecord r : records) {
            if (r.date.equals(date)) count++;
        }
        return count;
    }

    static int latestGoalForDate(List<StudyRecord> records, String date) {
        int goal = 0;
        for (StudyRecord r : records) {
            if (r.date.equals(date)) goal = r.goal;
        }
        return goal;
    }

    static int calculateStreak(List<StudyRecord> records) {
        Set<String> dates = new HashSet<>();

        for (StudyRecord r : records) {
            if (r.study > 0) dates.add(r.date);
        }

        int streak = 0;
        LocalDate day = LocalDate.now();

        while (dates.contains(day.toString())) {
            streak++;
            day = day.minusDays(1);
        }

        return streak;
    }

    static int totalAllStudy(List<StudyRecord> records) {
        int total = 0;
        for (StudyRecord r : records) {
            total += r.study;
        }
        return total;
    }

    static int weeklyStudy(List<StudyRecord> records) {
        int total = 0;
        LocalDate today = LocalDate.now();

        for (int i = 0; i < 7; i++) {
            String date = today.minusDays(i).toString();
            total += totalStudyForDate(records, date);
        }

        return total;
    }

    static String achievementBadge(int totalStudy) {
        if (totalStudy >= 500) {
            return "🥇 Study Champion";
        } else if (totalStudy >= 100) {
            return "🥈 Consistent Learner";
        } else {
            return "🥉 Beginner Learner";
        }
    }

    static String bestDay(List<StudyRecord> records) {
        Map<String, Integer> dailyTotals = new HashMap<>();

        for (StudyRecord r : records) {
            dailyTotals.put(r.date, dailyTotals.getOrDefault(r.date, 0) + r.study);
        }

        String bestDate = "No data";
        int bestTime = 0;

        for (String date : dailyTotals.keySet()) {
            if (dailyTotals.get(date) > bestTime) {
                bestTime = dailyTotals.get(date);
                bestDate = date;
            }
        }

        if (bestTime == 0) {
            return "No data";
        }

        return bestDate + " (" + bestTime + " min)";
    }

    @GetMapping("/")
    public String home(HttpSession session) {
        if (session.getAttribute("email") != null) {
            return "redirect:/dashboard";
        }
        return "index";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String name,
                           @RequestParam String email,
                           @RequestParam String password,
                           HttpSession session) {

        users.put(email, password);
        names.put(email, name);
        userHistory.putIfAbsent(email, new ArrayList<>());

        saveUsers();

        session.setAttribute("email", email);
        session.setAttribute("name", name);

        return "redirect:/dashboard";
    }

    @GetMapping("/login")
    public String loginPage(HttpSession session) {
        if (session.getAttribute("email") != null) {
            return "redirect:/dashboard";
        }
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {

        if (users.containsKey(email) && users.get(email).equals(password)) {
            session.setAttribute("email", email);
            session.setAttribute("name", names.get(email));
            return "redirect:/dashboard";
        }

        model.addAttribute("error", "Invalid email or password");
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        String email = (String) session.getAttribute("email");

        if (email == null) {
            return "redirect:/login";
        }

        List<StudyRecord> records = userHistory.getOrDefault(email, new ArrayList<>());

        String today = LocalDate.now().toString();
        String yesterday = LocalDate.now().minusDays(1).toString();

        int todayStudy = totalStudyForDate(records, today);
        int yesterdayStudy = totalStudyForDate(records, yesterday);
        int difference = todayStudy - yesterdayStudy;

        String comparisonMessage;

        if (difference > 0) {
            comparisonMessage = "Great! You studied " + difference + " min more than yesterday.";
        } else if (difference < 0) {
            comparisonMessage = "You studied " + Math.abs(difference) + " min less than yesterday. Try to improve today.";
        } else {
            comparisonMessage = "Your study time is same as yesterday.";
        }

        int weeklyTotal = weeklyStudy(records);
        int weeklyAverage = weeklyTotal / 7;
        int totalStudy = totalAllStudy(records);

        model.addAttribute("name", session.getAttribute("name"));
        model.addAttribute("goal", latestGoalForDate(records, today));
        model.addAttribute("todayStudy", todayStudy);
        model.addAttribute("yesterdayStudy", yesterdayStudy);
        model.addAttribute("difference", difference);
        model.addAttribute("comparisonMessage", comparisonMessage);
        model.addAttribute("streak", calculateStreak(records));
        model.addAttribute("sessions", sessionsForDate(records, today));

        model.addAttribute("weeklyTotal", weeklyTotal);
        model.addAttribute("weeklyAverage", weeklyAverage);
        model.addAttribute("bestDay", bestDay(records));
        model.addAttribute("achievement", achievementBadge(totalStudy));
        model.addAttribute("totalStudy", totalStudy);

        return "dashboard";
    }

    @GetMapping("/study")
    public String studyPage(HttpSession session) {
        if (session.getAttribute("email") == null) {
            return "redirect:/login";
        }
        return "study";
    }

    @PostMapping("/saveStudy")
    public String saveStudy(@RequestParam String subject,
                            @RequestParam int goal,
                            @RequestParam int studyMinutes,
                            @RequestParam int phoneUsage,
                            @RequestParam int distractions,
                            HttpSession session) {

        String email = (String) session.getAttribute("email");

        if (email == null) {
            return "redirect:/login";
        }

        StudyRecord record = new StudyRecord(
                LocalDate.now().toString(),
                subject,
                goal,
                studyMinutes,
                phoneUsage,
                distractions
        );

        userHistory.putIfAbsent(email, new ArrayList<>());
        userHistory.get(email).add(record);

        saveHistory();

        return "redirect:/report";
    }

    @GetMapping("/report")
    public String report(HttpSession session, Model model) {
        String email = (String) session.getAttribute("email");

        if (email == null) {
            return "redirect:/login";
        }

        List<StudyRecord> records = userHistory.getOrDefault(email, new ArrayList<>());

        if (records.isEmpty()) {
            model.addAttribute("subject", "No session recorded yet");
            model.addAttribute("goal", 0);
            model.addAttribute("study", 0);
            model.addAttribute("phone", 0);
            model.addAttribute("distractions", 0);
            model.addAttribute("goalCompletion", 0);
            model.addAttribute("productivity", 0);
            model.addAttribute("history", new ArrayList<String>());
            return "report";
        }

        StudyRecord latest = records.get(records.size() - 1);
        List<String> historyList = new ArrayList<>();

        for (int i = records.size() - 1; i >= 0; i--) {
            historyList.add(records.get(i).display());
        }

        model.addAttribute("subject", latest.subject);
        model.addAttribute("goal", latest.goal);
        model.addAttribute("study", latest.study);
        model.addAttribute("phone", latest.phone);
        model.addAttribute("distractions", latest.distractions);
        model.addAttribute("goalCompletion", latest.goalCompletion);
        model.addAttribute("productivity", latest.productivity);
        model.addAttribute("history", historyList);

        return "report";
    }

    @GetMapping("/export")
    public void exportReport(HttpSession session, HttpServletResponse response) {
        try {
            String email = (String) session.getAttribute("email");

            if (email == null) {
                response.sendRedirect("/login");
                return;
            }

            List<StudyRecord> records = userHistory.getOrDefault(email, new ArrayList<>());

            response.setContentType("text/plain");
            response.setHeader("Content-Disposition", "attachment; filename=study-report.txt");

            PrintWriter writer = response.getWriter();

            writer.println("Lumina - Smart Study Focus & Distraction Tracker");
            writer.println("Student: " + names.get(email));
            writer.println("Email: " + email);
            writer.println("-------------------------------------------");

            if (records.isEmpty()) {
                writer.println("No study records found.");
            } else {
                for (StudyRecord r : records) {
                    writer.println(r.display());
                }
            }

            writer.flush();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @GetMapping("/reset")
    public String reset(HttpSession session) {
        String email = (String) session.getAttribute("email");

        if (email == null) {
            return "redirect:/login";
        }

        userHistory.put(email, new ArrayList<>());
        saveHistory();

        return "redirect:/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}